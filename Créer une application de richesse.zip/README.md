
  # Créer une application de richesse

  This is a code bundle for Créer une application de richesse. The original project is available at https://www.figma.com/design/YHsuEvjxFcaLKyUqzt3IF5/Cr%C3%A9er-une-application-de-richesse.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  